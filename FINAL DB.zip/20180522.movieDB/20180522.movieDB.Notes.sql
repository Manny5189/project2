select 
	distinct
    mm.*
from movie_metadata mm
	inner join genresearch gs
		on mm.mmid = gs.mmid
	inner join plotkeywordsearch pks
		on mm.mmid = pks.mmid
	inner join actorsearch a
		on mm.mmid = a.mmid
where gs.genre = 'comedy'
and pks.keyword = 'mafia'
and a.actor_name like '%de niro%';

select 
	distinct
    mm.*
from movie_metadata mm
	inner join genresearch gs
		on mm.mmid = gs.mmid
	inner join plotkeywordsearch pks
		on mm.mmid = pks.mmid
	inner join actorsearch a
		on mm.mmid = a.mmid
where (pks.keyword = 'fighting' or pks.keyword = 'shooting')
